const MongoClient = require('mongodb').MongoClient;
const uri = 'mongodb+srv://SoPrettyPink:pINKY@sobicluster.thoc8.mongodb.net/salon-locator?retryWrites=true&w=majority';
const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });
client.connect(err => {
  const collection = client.db("test").collection("devices");
  // perform actions on the collection object
  client.close();
});
const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/salon-locator', {useNewUrlParser: true}, (err) => {
if (!err) {
	console.log('Successfully Established Connection with MongoDB')
}
else {
	console.log('Failed to Establish Connection with MongoDB with Error: '+ err)
}
});

//Connecting Node and MongoDB
require('./course.model');


async function main() {
  const MongoClient = require('mongodb').MongoClient;
  const uri =
    'mongodb+srv://SoPrettyPink:pINKY@sobicluster.thoc8.mongodb.net/salon-locator?retryWrites=true&w=majority';
  const client = new MongoClient(uri, { useNewUrlParser: true });

  //Connect to the client and query
  try {
  	await client.connect(); //Connect to the MongoDB cluster

  	await listDatabases(client); //Make appropriate calls
  } catch (e) {
  		console.error(e);
  }
}

main().catch(console.error);

async function listDatabases(client) {
	databasesList = await client.db().admin().listDatabases();

	console.log("Databases:");
	databasesList.databases.forEach(db =? console.log(' - ${db.salon-locator}'));
};

async function salonlisting(client, resultsLimit) {
  const cursor = client
    .db('salon-locator')
    .collection('users')
    .find()
    .limit(resultsLimit);

  const results = await cursor.toArray();
  if (results.length > 0) {
    console.log(`Found ${results.length} salon(s):`);
    results.forEach((result, i) => {
      date = new Date(result.last_review).toDateString();

      console.log();
      console.log(`${i + 1}. name: ${result.name}`);
      console.log(`   _id: ${result._id}`);
      console.log(`   salon_name: ${result.salon_name}`);
      console.log(`   favorites: ${result.favorites}`);
      }`
      );
    });
  }
}

